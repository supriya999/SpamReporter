package com.spam.reporter.dto;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "source",
        "reportType",
        "message",
        "reportId",
        "referenceResourceId",
        "referenceResourceType"
})
@Data
public class Payload {

    @JsonProperty("source")
    private String source;
    @JsonProperty("reportType")
    private String reportType;
    @JsonProperty("message")
    private Object message;
    @JsonProperty("reportId")
    private String reportId;
    @JsonProperty("referenceResourceId")
    private String referenceResourceId;
    @JsonProperty("referenceResourceType")
    private String referenceResourceType;

}
