package com.spam.reporter.dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spam.reporter.dto.Element;
import com.spam.reporter.dto.Report;
import com.spam.reporter.exception.SpamReporterException;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Component
@Slf4j
public class ReporterDao {

    private Report report;

    private List<Element> blockedList;

    @PostConstruct
    public void init() throws IOException {
        report=getReportFromSource();
    }

    /**
     * method to update status of report element
     * @param reportID
     * @param state
     * @throws SpamReporterException
     */
    public void updateTicket(String reportID, String state) throws SpamReporterException {
        if (null == report) {
            throw new SpamReporterException("No Report Data Available at this moment");
        } else if (null == reportID || null == state) {
            throw new SpamReporterException("Invalid input data provided");
        }
        log.info("Updating status as:"+state+" report for id:",reportID);

        List<Element> elementList = getAllReportData();
        elementList.stream().filter(element->  element.getId().equalsIgnoreCase(reportID))
                        .forEach(element -> element.setState(state));
        report.setElements(elementList);
    }

    /**
     * method to get updated report data
     * @return list with updated report elements
     */
    public List<Element> getAllReportData(){
        log.info("Loading updated report data");

        List<Element> elementList = report.getElements();
        elementList.removeIf(element -> null != element.getState() && "CLOSE".equalsIgnoreCase(element.getState()));
        report.setElements(elementList);
        return elementList;
    }

    /**
     * method to block a specific reportId
     * @param reportID
     */
    @SneakyThrows
    public void blockReportId(String reportID){
        log.info("Blocking report for id:",reportID);
        if(CollectionUtils.isEmpty(blockedList)){
            blockedList=new ArrayList<>();
        }
        report.getElements()
                .stream()
                .filter(element -> element.getId().equalsIgnoreCase(reportID))
                .forEach(element -> blockedList.add(element));
        updateTicket(reportID,"CLOSE");
        //Blocked List can be used for any further usecase extenstion.For now just logging it.
        blockedList.forEach(element -> log.info(element.getId()));
    }

    /**
     * method for initial load of data
     * @return Report data
     * @throws IOException
     */
    private Report getReportFromSource() throws IOException {
        log.info("Loading initial report data");
        ObjectMapper objectMapper = new ObjectMapper();
        //return objectMapper.readValue(new File("src/test/resources/SampleReportWith3Elements.json"), Report.class);
        return objectMapper.readValue(new File("src/test/resources/SampleReport.json"), Report.class);

    }

}
