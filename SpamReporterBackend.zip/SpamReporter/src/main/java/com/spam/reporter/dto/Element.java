package com.spam.reporter.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "id",
        "source",
        "sourceIdentityId",
        "reference",
        "state",
        "payload",
        "created"
})
@Data
public class Element {

    @JsonProperty("id")
    private String id;
    @JsonProperty("source")
    private String source;
    @JsonProperty("sourceIdentityId")
    private String sourceIdentityId;
    @JsonProperty("reference")
    private Reference reference;
    @JsonProperty("state")
    private String state;
    @JsonProperty("payload")
    private Payload payload;
    @JsonProperty("created")
    private String created;

    @Override
    public String toString() {
        return "Element{" +
                "id='" + id + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
