package com.spam.reporter.controller;

import com.spam.reporter.dto.Element;
import com.spam.reporter.dto.TicketRequest;
import com.spam.reporter.exception.SpamReporterException;
import com.spam.reporter.service.ReporterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin("http://localhost:4200/")
public class ReportController {

    @Autowired
    ReporterService reporterService;

    @RequestMapping(value="/reports/getReports", method = RequestMethod.GET)
    public List<Element> getReport(){
       return reporterService.getAllReportData();
    }


    @RequestMapping(value = "/reports/{reportId}", method = RequestMethod.PUT)
    public @ResponseBody String updateTicket(@PathVariable("reportId") String id,@RequestBody TicketRequest ticketRequest)
            throws IOException, SpamReporterException {
        reporterService.updateTicket(id,ticketRequest.getState());
        return "Status updated successfully for report id:"+id;
    }

    @RequestMapping(value = "/reports/block/{reportId}", method = RequestMethod.POST)
    public @ResponseBody String blockReportId(@PathVariable("reportId") String id) {
        reporterService.blockReportId(id);
        return "Blocked successfully report id:"+id;
    }
}
