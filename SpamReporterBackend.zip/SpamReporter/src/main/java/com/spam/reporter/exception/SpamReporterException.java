package com.spam.reporter.exception;

public class SpamReporterException extends Exception{

    public SpamReporterException(String errorMessage) {
        super(errorMessage);
    }

}
