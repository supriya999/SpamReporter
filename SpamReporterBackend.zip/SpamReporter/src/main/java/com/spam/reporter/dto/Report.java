package com.spam.reporter.dto;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "size",
        "nextOffset",
        "elements"
})
@Data
public class Report {

    @JsonProperty("size")
    private Integer size;
    @JsonProperty("nextOffset")
    private String nextOffset;
    @JsonProperty("elements")
    private List<Element> elements = null;

    @Override
    public String toString() {
        return "Report{" +
                "elements=" + elements +
                '}';
    }
}