package com.spam.reporter.service;

import com.spam.reporter.dao.ReporterDao;
import com.spam.reporter.dto.Element;
import com.spam.reporter.exception.SpamReporterException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;

@Component
public class ReporterService {

    @Autowired
    ReporterDao reporterDao;

    public List<Element> getAllReportData(){
        return reporterDao.getAllReportData();
    }

    public void updateTicket(String reportID, String state) throws SpamReporterException {
        reporterDao.updateTicket(reportID,state);
    }

    public void blockReportId(String id) {
        reporterDao.blockReportId(id);
    }
}
