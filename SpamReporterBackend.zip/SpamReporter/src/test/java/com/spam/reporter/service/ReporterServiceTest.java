package com.spam.reporter.service;

import com.spam.reporter.dto.Element;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
@ComponentScan(basePackages = "com.spam")
@Slf4j
class ReporterServiceTest {

    @Autowired
    ReporterService reporterService;


    @Test
    void getAllReportData() {
        List<Element> elementList=reporterService.getAllReportData();
        Assert.assertNotNull(elementList);
    }


    @Test
    void updateTicket() throws Exception {
        List <Element> elementList=reporterService.getAllReportData();
        int beforeSize=elementList.size();
        reporterService.updateTicket(elementList.get(0).getId(),"CLOSE");
        List <Element> afterElementList=reporterService.getAllReportData();
        Assert.assertEquals(beforeSize-1,afterElementList.size());
    }

    @Test
    void blockReportId() {
        List <Element> elementList=reporterService.getAllReportData();
        elementList.stream().filter(element->  element.getId().equalsIgnoreCase(elementList.get(0).getId()))
                .forEach(element -> element.setState("TEST"));

        String afterState=null;
        List <Element> afterList=reporterService.getAllReportData();
        for (Element element : elementList) {
            if (element.getId().equalsIgnoreCase(elementList.get(0).getId())) {
                afterState=element.getState();
            }
        }

        Assert.assertEquals(afterState,elementList.get(0).getState());
    }
}