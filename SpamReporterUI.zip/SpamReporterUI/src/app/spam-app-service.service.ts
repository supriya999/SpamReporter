import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class SpamAppServiceService {

  environmentUrl: string;
  requests: any;

  constructor(private http: HttpClient) {
    this.environmentUrl = environment.apiUrl;
  }


  getReportData(): Observable<any> {
    console.log("In getdata");
    return this.http.get(`${this.environmentUrl}/reports/getReports`);
    //.subscribe(res=>this.requests=res);

 }

  // Update the existing record on demand detail form
  resolve(reportId: string, filterData: any): Observable<any> {

    const headers = { 'content-type': 'application/json'} 
    const body=JSON.stringify(filterData); 
    return this.http.put(`${this.environmentUrl}/reports/${reportId}`, body,{'headers':headers});

  }


  blockReport(reportId: any): Observable<any> {
    return this.http.post(`${this.environmentUrl}/reports/block/${reportId}`,reportId);
}

}


