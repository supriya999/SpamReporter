import { Component, OnInit } from '@angular/core';
import { SpamAppServiceService } from './spam-app-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'spam-reporter-app';


  name = 'Angular';
  tempInput: any;

  inputRecords: any = [];

  constructor(

    private spamService: SpamAppServiceService,

  ) {

  }


  ngOnInit(): void {
    console.log("In init");
    //this.inputRecords = this.spamService.getReportData();
    this.getReportdata();
    console.log("Post init");

  }

  getReportdata() {

    this.spamService.getReportData().subscribe(
      (response) => { 
        this.inputRecords=response;
        
      });
    //  this.tempInput = this.spamService.getReportData();
    //  this.inputRecords=this.tempInput;
    console.log(this.inputRecords);

  }


  blockAccess(id) {
    this.spamService.blockReport(id).subscribe((response) => {

      alert({ severity: 'success', summary: 'Success Message' });

    }, (error) => {

      alert({ severity: 'error', summary: 'Error Message' });

    }
    );

    this.getReportdata();

  }

  resolveAccess(id) {
    console.log('this' + id);

    this.spamService.resolve(id, id).subscribe(
      (response) => {

        alert({ severity: 'success', summary: 'Success Message' });

      }, (error) => {

        alert({ severity: 'error', summary: 'Error Message' });
      }
    );

    this.getReportdata();

  }

  onGoToPage2() {

    if (confirm('This is report details')) {
      console.log('Implement delete functionality here');
    }

  }
}
