import { TestBed } from '@angular/core/testing';

import { SpamAppServiceService } from './spam-app-service.service';

describe('SpamAppServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SpamAppServiceService = TestBed.get(SpamAppServiceService);
    expect(service).toBeTruthy();
  });
});
